import { Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { InjectModel } from '@nestjs/sequelize';
import { Products } from './products.madel';

@Injectable()
export class ProductsService {
  constructor(
    @InjectModel(Products) private readonly productsModel: typeof Products,
  ) {}

  async create(createProductDto: CreateProductDto, request: any) {
    const id = request.user.id;

    return await this.productsModel.create({
      ...createProductDto,
      user_id: id,
    });
  }

  findAll() {
    return this.productsModel.findAll();
  }

  findOne(id: number) {
    return this.productsModel.findOne({ where: { id } });
  }

  update(id: number, updateProductDto: UpdateProductDto) {
    return this.productsModel.update(updateProductDto, { where: { id } });
  }

  remove(id: number) {
    return this.productsModel.destroy({ where: { id } });
  }
}
