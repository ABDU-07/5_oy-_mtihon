import { Model, Column, DataType, Table } from 'sequelize-typescript';

@Table({ tableName: 'products' })
export class Products extends Model<Products> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  user_id: string;
}
