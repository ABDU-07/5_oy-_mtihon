import { Module } from '@nestjs/common';
import { ProductsModule } from './products/products.module';
import { SequelizeModule } from '@nestjs/sequelize';

@Module({
  imports: [
    ProductsModule,
    SequelizeModule.forRoot({
      dialect: 'postgres',
      database: 'postgres',
      username: 'postgres',
      password: '123456',
      host: 'localhost',
      port: 5432,
      autoLoadModels: true,
      synchronize: true,
    }),
  ],
})
export class AppModule {}
