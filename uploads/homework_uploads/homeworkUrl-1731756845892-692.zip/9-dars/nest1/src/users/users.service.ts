import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectModel } from '@nestjs/sequelize';
import { Users } from './users.madel';
import * as jwt from 'jsonwebtoken';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(@InjectModel(Users) private readonly usersModel: typeof Users) {}

  async register(createUserDto: CreateUserDto) {
    createUserDto.password = await bcrypt.hash(createUserDto.password, 10);
    const result = await this.usersModel.create(createUserDto);
    return result;
  }
  async login(createUserDto: CreateUserDto) {
    const result = await this.findOneEmail(createUserDto.email);
    if (!result) {
      return 'Email yoki Parol xato';
    }
    const checkPassword = await bcrypt.compare(
      createUserDto.password,
      result.password,
    );
    if (!checkPassword) {
      return 'Email yoki Parol xato';
    }

    const accesToken = await this.token({ email: result.email });
    return { accesToken };
  }

  findAll() {
    return `This action returns all users`;
  }

  findOne(email: string) {
    return this.usersModel.findOne({ where: { email } });
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }

  async token(data) {
    const accessSecret = 'salom';
    return jwt.sign(data, accessSecret, {
      expiresIn: '60m',
    });
  }

  findOneEmail(email: string) {
    return this.usersModel.findOne({ where: { email } });
  }
}
